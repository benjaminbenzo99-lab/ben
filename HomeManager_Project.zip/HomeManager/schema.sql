CREATE DATABASE IF NOT EXISTS home_manager
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE home_manager;

CREATE TABLE IF NOT EXISTS expenses (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kind ENUM('income','expense') NOT NULL DEFAULT 'expense',
  title VARCHAR(120) NOT NULL,
  category VARCHAR(80) NOT NULL DEFAULT 'Other',
  amount DECIMAL(12,2) NOT NULL,
  transaction_date DATE NOT NULL,
  notes VARCHAR(500) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_expenses_date (transaction_date),
  INDEX idx_expenses_kind (kind)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS inventory (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  item_name VARCHAR(120) NOT NULL,
  category VARCHAR(80) NOT NULL DEFAULT 'Other',
  quantity DECIMAL(10,2) NOT NULL DEFAULT 0,
  unit VARCHAR(30) NOT NULL DEFAULT 'item',
  minimum_quantity DECIMAL(10,2) NOT NULL DEFAULT 1,
  expiry_date DATE NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_inventory_name (item_name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS shopping_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  item_name VARCHAR(120) NOT NULL,
  quantity DECIMAL(10,2) NOT NULL DEFAULT 1,
  unit VARCHAR(30) NOT NULL DEFAULT 'item',
  estimated_cost DECIMAL(12,2) NOT NULL DEFAULT 0,
  purchased TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_shopping_purchased (purchased)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS chores (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  task_name VARCHAR(160) NOT NULL,
  assigned_to VARCHAR(100) NOT NULL DEFAULT 'Anyone',
  due_date DATE NULL,
  status ENUM('pending','done') NOT NULL DEFAULT 'pending',
  notes VARCHAR(500) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_chores_status (status),
  INDEX idx_chores_due_date (due_date)
) ENGINE=InnoDB;

/* Optional starter data. Remove these INSERTs if you prefer a blank database. */
INSERT INTO inventory (item_name, category, quantity, unit, minimum_quantity)
SELECT 'Rice', 'Food', 2, 'kg', 1
WHERE NOT EXISTS (SELECT 1 FROM inventory WHERE item_name = 'Rice');

INSERT INTO shopping_items (item_name, quantity, unit, estimated_cost)
SELECT 'Cooking oil', 1, 'bottle', 2500
WHERE NOT EXISTS (SELECT 1 FROM shopping_items WHERE item_name = 'Cooking oil');

INSERT INTO chores (task_name, assigned_to, due_date)
SELECT 'Clean the kitchen', 'Anyone', CURDATE()
WHERE NOT EXISTS (SELECT 1 FROM chores WHERE task_name = 'Clean the kitchen');
