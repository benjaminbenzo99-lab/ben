<?php
declare(strict_types=1);
session_start();
require __DIR__ . '/config.php';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
function h(mixed $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function redirectTo(string $section = 'dashboard'): never {
    header('Location: index.php?section=' . urlencode($section));
    exit;
}
function postString(string $key, int $max = 160): string {
    $value = trim((string)($_POST[$key] ?? ''));
    if ($value === '' || mb_strlen($value) > $max) {
        throw new InvalidArgumentException("Please enter a valid value for " . str_replace('_', ' ', $key) . ".");
    }
    return $value;
}
function postAmount(string $key, bool $allowZero = false): float {
    $raw = (string)($_POST[$key] ?? '');
    if (!is_numeric($raw)) throw new InvalidArgumentException('Enter a valid number.');
    $value = (float)$raw;
    if ($value < 0 || (!$allowZero && $value <= 0)) throw new InvalidArgumentException('Enter a valid positive amount.');
    return $value;
}
$pdo = db();
$error = '';
$notice = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!hash_equals($_SESSION['csrf'], (string)($_POST['csrf'] ?? ''))) {
            throw new RuntimeException('Security token invalid. Refresh the page and try again.');
        }
        $action = (string)($_POST['action'] ?? '');
        if ($action === 'add_expense') {
            $kind = in_array($_POST['kind'] ?? '', ['income','expense'], true) ? $_POST['kind'] : 'expense';
            $title = postString('title', 120);
            $category = postString('category', 80);
            $amount = postAmount('amount');
            $date = (string)($_POST['transaction_date'] ?? date('Y-m-d'));
            $notes = trim((string)($_POST['notes'] ?? ''));
            $stmt = $pdo->prepare('INSERT INTO expenses (kind,title,category,amount,transaction_date,notes) VALUES (?,?,?,?,?,?)');
            $stmt->execute([$kind,$title,$category,$amount,$date,$notes !== '' ? $notes : null]);
            redirectTo('expenses');
        } elseif ($action === 'add_inventory') {
            $stmt = $pdo->prepare('INSERT INTO inventory (item_name,category,quantity,unit,minimum_quantity,expiry_date) VALUES (?,?,?,?,?,?)');
            $expiry = trim((string)($_POST['expiry_date'] ?? ''));
            $stmt->execute([
                postString('item_name',120), postString('category',80),
                postAmount('quantity', true), postString('unit',30),
                postAmount('minimum_quantity', true), $expiry !== '' ? $expiry : null
            ]);
            redirectTo('inventory');
        } elseif ($action === 'update_inventory') {
            $id = (int)($_POST['id'] ?? 0);
            $quantity = postAmount('quantity', true);
            $stmt = $pdo->prepare('UPDATE inventory SET quantity=? WHERE id=?');
            $stmt->execute([$quantity,$id]);
            redirectTo('inventory');
        } elseif ($action === 'add_shopping') {
            $stmt = $pdo->prepare('INSERT INTO shopping_items (item_name,quantity,unit,estimated_cost) VALUES (?,?,?,?)');
            $stmt->execute([postString('item_name',120),postAmount('quantity'),postString('unit',30),postAmount('estimated_cost',true)]);
            redirectTo('shopping');
        } elseif ($action === 'toggle_shopping') {
            $id = (int)($_POST['id'] ?? 0);
            $stmt = $pdo->prepare('UPDATE shopping_items SET purchased = 1 - purchased WHERE id=?');
            $stmt->execute([$id]);
            redirectTo('shopping');
        } elseif ($action === 'add_chore') {
            $due = trim((string)($_POST['due_date'] ?? ''));
            $notes = trim((string)($_POST['notes'] ?? ''));
            $stmt = $pdo->prepare('INSERT INTO chores (task_name,assigned_to,due_date,notes) VALUES (?,?,?,?)');
            $stmt->execute([postString('task_name',160),postString('assigned_to',100),$due !== '' ? $due : null,$notes !== '' ? $notes : null]);
            redirectTo('chores');
        } elseif ($action === 'toggle_chore') {
            $id = (int)($_POST['id'] ?? 0);
            $stmt = $pdo->prepare("UPDATE chores SET status = IF(status='done','pending','done') WHERE id=?");
            $stmt->execute([$id]);
            redirectTo('chores');
        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $table = (string)($_POST['table'] ?? '');
            $allowed = ['expenses','inventory','shopping_items','chores'];
            if (!in_array($table, $allowed, true)) throw new RuntimeException('Invalid delete request.');
            $stmt = $pdo->prepare("DELETE FROM `$table` WHERE id=?");
            $stmt->execute([$id]);
            redirectTo((string)($_POST['return_to'] ?? 'dashboard'));
        } else {
            throw new RuntimeException('Unknown action.');
        }
    } catch (Throwable $e) {
        $error = $e instanceof PDOException
            ? 'Database error. Check that you imported schema.sql and that MySQL is running.'
            : $e->getMessage();
    }
}

$section = (string)($_GET['section'] ?? 'dashboard');
$validSections = ['dashboard','expenses','inventory','shopping','chores'];
if (!in_array($section, $validSections, true)) $section = 'dashboard';

$monthStart = date('Y-m-01');
$monthEnd = date('Y-m-t');
$incomeStmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE kind='income' AND transaction_date BETWEEN ? AND ?");
$incomeStmt->execute([$monthStart,$monthEnd]); $monthlyIncome = (float)$incomeStmt->fetchColumn();
$expenseStmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE kind='expense' AND transaction_date BETWEEN ? AND ?");
$expenseStmt->execute([$monthStart,$monthEnd]); $monthlyExpenses = (float)$expenseStmt->fetchColumn();
$lowStock = (int)$pdo->query('SELECT COUNT(*) FROM inventory WHERE quantity <= minimum_quantity')->fetchColumn();
$pendingChores = (int)$pdo->query("SELECT COUNT(*) FROM chores WHERE status='pending'")->fetchColumn();
$shoppingCount = (int)$pdo->query('SELECT COUNT(*) FROM shopping_items WHERE purchased=0')->fetchColumn();

$expenses = $pdo->query('SELECT * FROM expenses ORDER BY transaction_date DESC,id DESC LIMIT 100')->fetchAll();
$inventory = $pdo->query('SELECT * FROM inventory ORDER BY (quantity <= minimum_quantity) DESC,item_name')->fetchAll();
$shopping = $pdo->query('SELECT * FROM shopping_items ORDER BY purchased ASC,id DESC')->fetchAll();
$chores = $pdo->query("SELECT * FROM chores ORDER BY (status='pending') DESC, due_date IS NULL, due_date ASC,id DESC")->fetchAll();
$recentExpenses = $pdo->query('SELECT * FROM expenses ORDER BY transaction_date DESC,id DESC LIMIT 5')->fetchAll();

function navLink(string $name, string $label, string $current): string {
    return '<a class="nav-link '.($name === $current ? 'active' : '').'" href="index.php?section='.h($name).'">'.h($label).'</a>';
}
function deleteForm(string $table, int $id, string $section): string {
    return '<form method="post" class="inline-form" onsubmit="return confirm(\'Delete this record?\')">
      <input type="hidden" name="csrf" value="'.h($_SESSION['csrf']).'">
      <input type="hidden" name="action" value="delete"><input type="hidden" name="table" value="'.h($table).'">
      <input type="hidden" name="id" value="'.$id.'"><input type="hidden" name="return_to" value="'.h($section).'">
      <button class="btn btn-danger btn-small" type="submit">Delete</button></form>';
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Home Manager</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="app-shell">
  <aside class="sidebar">
    <a class="brand" href="index.php"><span class="brand-mark">⌂</span><span>Home<span class="brand-light">Manager</span><small>YOUR HOME, ORGANIZED</small></span></a>
    <div class="nav-label">WORKSPACE</div>
    <?=navLink('dashboard','▦  Dashboard',$section)?>
    <?=navLink('expenses','↗  Expenses',$section)?>
    <?=navLink('shopping','🛒  Shopping list',$section)?>
    <?=navLink('inventory','▤  Inventory',$section)?>
    <?=navLink('chores','✓  Family chores',$section)?>
    <div class="sidebar-note"><span class="online-dot"></span> Local home network <small>Data is stored in your MySQL database.</small></div>
  </aside>
  <main class="main">
    <header class="topbar">
      <div><div class="eyebrow">HOME MANAGEMENT</div><h1><?=h(['dashboard'=>'Overview','expenses'=>'Household expenses','inventory'=>'Home inventory','shopping'=>'Shopping list','chores'=>'Family chores'][$section])?></h1></div>
      <div class="today"><?=h(date('D, d M Y'))?></div>
    </header>
    <?php if ($error !== ''): ?><div class="alert error"><?=h($error)?></div><?php endif; ?>

    <?php if ($section === 'dashboard'): ?>
      <section class="welcome-panel"><div><div class="eyebrow light">YOUR HOME AT A GLANCE</div><h2>A calmer, more organized home starts here.</h2><p>Keep household money, supplies, shopping and daily responsibilities in one place.</p></div><div class="welcome-icon">⌂</div></section>
      <div class="section-heading"><div><h2>Monthly overview</h2><p>Summary for <?=h(date('F Y'))?></p></div></div>
      <div class="stats-grid">
        <article class="stat-card"><div class="stat-top"><span>Money in</span><span class="stat-icon green">↙</span></div><strong><?=number_format($monthlyIncome,0)?> <small>RWF</small></strong><p>Income this month</p></article>
        <article class="stat-card"><div class="stat-top"><span>Money out</span><span class="stat-icon coral">↗</span></div><strong><?=number_format($monthlyExpenses,0)?> <small>RWF</small></strong><p>Expenses this month</p></article>
        <article class="stat-card"><div class="stat-top"><span>Low stock</span><span class="stat-icon amber">!</span></div><strong><?=$lowStock?></strong><p>Items to check</p></article>
        <article class="stat-card"><div class="stat-top"><span>Pending chores</span><span class="stat-icon blue">✓</span></div><strong><?=$pendingChores?></strong><p>Tasks not completed</p></article>
      </div>
      <div class="content-grid">
        <section class="panel"><div class="panel-heading"><div><h3>Recent transactions</h3><p>Your latest household money records</p></div><a class="text-link" href="index.php?section=expenses">View all →</a></div>
          <?php if (!$recentExpenses): ?><div class="empty-state">No transactions yet. Add your first income or expense.</div><?php else: ?>
          <div class="table-wrap"><table><thead><tr><th>DESCRIPTION</th><th>DATE</th><th>AMOUNT</th></tr></thead><tbody>
          <?php foreach($recentExpenses as $e): ?><tr><td><b><?=h($e['title'])?></b><small class="cell-sub"><?=h($e['category'])?></small></td><td><?=h($e['transaction_date'])?></td><td class="<?=$e['kind']==='income'?'positive':'negative'?>"><?=$e['kind']==='income'?'+':'−'?><?=number_format((float)$e['amount'],0)?> RWF</td></tr><?php endforeach; ?>
          </tbody></table></div><?php endif; ?>
        </section>
        <section class="panel quick-panel"><div class="panel-heading"><div><h3>Quick actions</h3><p>Keep things up to date</p></div></div>
          <a class="quick-action" href="index.php?section=expenses"><span class="quick-icon coral">＋</span><span><b>Record a transaction</b><small>Income or household expense</small></span><span class="arrow">→</span></a>
          <a class="quick-action" href="index.php?section=shopping"><span class="quick-icon amber">＋</span><span><b>Add to shopping list</b><small><?=$shoppingCount?> item(s) still to buy</small></span><span class="arrow">→</span></a>
          <a class="quick-action" href="index.php?section=inventory"><span class="quick-icon green">＋</span><span><b>Update home stock</b><small><?=$lowStock?> item(s) at low stock</small></span><span class="arrow">→</span></a>
          <a class="quick-action" href="index.php?section=chores"><span class="quick-icon blue">＋</span><span><b>Assign a family task</b><small><?=$pendingChores?> pending task(s)</small></span><span class="arrow">→</span></a>
        </section>
      </div>
    <?php elseif ($section === 'expenses'): ?>
      <section class="panel form-panel"><div class="panel-heading"><div><h3>Add transaction</h3><p>Enter household income or spending. Amounts are in Rwandan francs (RWF).</p></div></div>
      <form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="add_expense">
        <label>Type<select name="kind"><option value="expense">Expense</option><option value="income">Income</option></select></label>
        <label>Description<input name="title" maxlength="120" placeholder="e.g. Electricity payment" required></label>
        <label>Category<select name="category"><option>Food</option><option>Utilities</option><option>Transport</option><option>Rent</option><option>School</option><option>Health</option><option>Salary</option><option>Business</option><option>Other</option></select></label>
        <label>Amount (RWF)<input type="number" name="amount" min="1" step="1" required placeholder="e.g. 15000"></label>
        <label>Date<input type="date" name="transaction_date" value="<?=h(date('Y-m-d'))?>" required></label>
        <label class="span-two">Notes (optional)<input name="notes" maxlength="500" placeholder="Additional details"></label>
        <div class="span-two"><button class="btn btn-primary" type="submit">＋ Save transaction</button></div>
      </form></section>
      <section class="panel"><div class="panel-heading"><div><h3>Transaction history</h3><p>Most recent 100 records</p></div></div>
      <?php if (!$expenses): ?><div class="empty-state">No transactions recorded yet.</div><?php else: ?><div class="table-wrap"><table><thead><tr><th>DESCRIPTION</th><th>CATEGORY</th><th>DATE</th><th>AMOUNT</th><th></th></tr></thead><tbody><?php foreach($expenses as $e): ?><tr><td><b><?=h($e['title'])?></b><small class="cell-sub"><?=h($e['kind'])?></small></td><td><?=h($e['category'])?></td><td><?=h($e['transaction_date'])?></td><td class="<?=$e['kind']==='income'?'positive':'negative'?>"><?=number_format((float)$e['amount'],0)?> RWF</td><td><?=deleteForm('expenses',(int)$e['id'],'expenses')?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
    <?php elseif ($section === 'inventory'): ?>
      <section class="panel form-panel"><div class="panel-heading"><div><h3>Add home item</h3><p>Set a minimum quantity so low supplies are easy to spot.</p></div></div>
      <form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="add_inventory">
        <label>Item name<input name="item_name" required maxlength="120" placeholder="e.g. Rice"></label><label>Category<select name="category"><option>Food</option><option>Cleaning</option><option>Personal care</option><option>Kitchen</option><option>Other</option></select></label>
        <label>Quantity<input type="number" name="quantity" min="0" step="0.01" required value="1"></label><label>Unit<input name="unit" maxlength="30" required value="item" placeholder="kg, bottle, packet"></label>
        <label>Minimum quantity<input type="number" name="minimum_quantity" min="0" step="0.01" required value="1"></label><label>Expiry date (optional)<input type="date" name="expiry_date"></label>
        <div class="span-two"><button class="btn btn-primary" type="submit">＋ Add item</button></div>
      </form></section>
      <section class="panel"><div class="panel-heading"><div><h3>Items at home</h3><p>Items at or below their minimum are highlighted.</p></div></div>
      <?php if (!$inventory): ?><div class="empty-state">Your inventory is empty. Add items you keep at home.</div><?php else: ?><div class="table-wrap"><table><thead><tr><th>ITEM</th><th>CATEGORY</th><th>QUANTITY</th><th>MINIMUM</th><th>EXPIRY</th><th></th></tr></thead><tbody><?php foreach($inventory as $i): ?><tr><td><b><?=h($i['item_name'])?></b><?php if ((float)$i['quantity'] <= (float)$i['minimum_quantity']): ?><small class="cell-sub low-label">Low stock</small><?php endif; ?></td><td><?=h($i['category'])?></td><td><form method="post" class="quantity-form"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="update_inventory"><input type="hidden" name="id" value="<?=(int)$i['id']?>"><input class="quantity-input" type="number" name="quantity" min="0" step="0.01" value="<?=h($i['quantity'])?>" aria-label="Quantity for <?=h($i['item_name'])?>"><span><?=h($i['unit'])?></span><button class="btn btn-small" type="submit">Update</button></form></td><td><?=h($i['minimum_quantity'])?> <?=h($i['unit'])?></td><td><?=h($i['expiry_date'] ?: '—')?></td><td><?=deleteForm('inventory',(int)$i['id'],'inventory')?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
    <?php elseif ($section === 'shopping'): ?>
      <section class="panel form-panel"><div class="panel-heading"><div><h3>Add shopping item</h3><p>Plan what to buy and estimate the cost.</p></div></div>
      <form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="add_shopping">
        <label>Item name<input name="item_name" required maxlength="120" placeholder="e.g. Cooking oil"></label><label>Quantity<input type="number" name="quantity" min="0.01" step="0.01" value="1" required></label><label>Unit<input name="unit" maxlength="30" value="item" required placeholder="bottle, kg, packet"></label><label>Estimated cost (RWF)<input type="number" name="estimated_cost" min="0" step="1" value="0" required></label>
        <div class="span-two"><button class="btn btn-primary" type="submit">＋ Add to list</button></div>
      </form></section>
      <section class="panel"><div class="panel-heading"><div><h3>Your shopping list</h3><p><?=$shoppingCount?> item(s) left to buy</p></div><div class="budget-chip">Pending estimate: <?=number_format((float)$pdo->query('SELECT COALESCE(SUM(estimated_cost),0) FROM shopping_items WHERE purchased=0')->fetchColumn(),0)?> RWF</div></div>
      <?php if (!$shopping): ?><div class="empty-state">Nothing on the shopping list yet.</div><?php else: ?><div class="table-wrap"><table><thead><tr><th>ITEM</th><th>QUANTITY</th><th>ESTIMATED COST</th><th>STATUS</th><th></th></tr></thead><tbody><?php foreach($shopping as $s): ?><tr class="<?=$s['purchased']?'muted-row':''?>"><td><b><?=h($s['item_name'])?></b></td><td><?=h($s['quantity'])?> <?=h($s['unit'])?></td><td><?=number_format((float)$s['estimated_cost'],0)?> RWF</td><td><form method="post"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="toggle_shopping"><input type="hidden" name="id" value="<?=(int)$s['id']?>"><button class="status-pill <?=$s['purchased']?'done':'pending'?>" type="submit"><?=$s['purchased']?'✓ Purchased':'○ Mark purchased'?></button></form></td><td><?=deleteForm('shopping_items',(int)$s['id'],'shopping')?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></section>
    <?php elseif ($section === 'chores'): ?>
      <section class="panel form-panel"><div class="panel-heading"><div><h3>Create a family task</h3><p>Assign a task and optionally set a due date.</p></div></div>
      <form method="post" class="form-grid"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="add_chore">
        <label class="span-two">Task name<input name="task_name" maxlength="160" required placeholder="e.g. Sweep the living room"></label><label>Assigned to<input name="assigned_to" maxlength="100" required value="Anyone" placeholder="Family member"></label><label>Due date<input type="date" name="due_date"></label><label class="span-two">Notes (optional)<input name="notes" maxlength="500" placeholder="Instructions or details"></label>
        <div class="span-two"><button class="btn btn-primary" type="submit">＋ Add task</button></div>
      </form></section>
      <section class="panel"><div class="panel-heading"><div><h3>Family task board</h3><p>Mark tasks done when finished.</p></div></div>
      <?php if (!$chores): ?><div class="empty-state">No chores yet. Add the first task above.</div><?php else: ?><div class="chore-list"><?php foreach($chores as $c): ?><article class="chore-item <?=$c['status']==='done'?'chore-done':''?>"><form method="post"><input type="hidden" name="csrf" value="<?=h($_SESSION['csrf'])?>"><input type="hidden" name="action" value="toggle_chore"><input type="hidden" name="id" value="<?=(int)$c['id']?>"><button class="check-button" type="submit" aria-label="Toggle task status"><?=$c['status']==='done'?'✓':''?></button></form><div class="chore-info"><b><?=h($c['task_name'])?></b><small>Assigned to <?=h($c['assigned_to'])?> · Due <?=h($c['due_date'] ?: 'No date')?></small><?php if ($c['notes']): ?><small><?=h($c['notes'])?></small><?php endif; ?></div><span class="task-status <?=$c['status']==='done'?'done':'pending'?>"><?=h(ucfirst($c['status']))?></span><?=deleteForm('chores',(int)$c['id'],'chores')?></article><?php endforeach; ?></div><?php endif; ?></section>
    <?php endif; ?>
    <footer>Home Manager <span>·</span> Private household workspace <span>·</span> <?=h(date('Y'))?></footer>
  </main>
</div>
</body>
</html>
