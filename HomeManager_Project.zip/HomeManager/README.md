# Home Manager (PHP + MySQL + XAMPP)

A local household management web app for tracking expenses/income, shopping items, home inventory and family chores. It is designed to work on your laptop and other devices on the same trusted home Wi-Fi network.

## Requirements
- Windows with XAMPP (Apache and MySQL)
- A modern browser
- Phone connected to the same home Wi-Fi for phone access

## 1. Install the project
1. Extract the `HomeManager` folder from the ZIP.
2. Copy it into your XAMPP web directory, usually `C:\xampp\htdocs\HomeManager`.
3. Open the XAMPP Control Panel and start **Apache** and **MySQL**.

## 2. Create the database
1. On the laptop, open `http://localhost/phpmyadmin`.
2. Select the **Import** tab.
3. Choose the `schema.sql` file inside the `HomeManager` folder.
4. Click **Import** or **Go**. This creates the `home_manager` database and its tables.

## 3. Open the app
On your laptop, visit `http://localhost/HomeManager/`.

If your MySQL `root` user has a password, edit `config.php` and set `DB_PASS` to that password. The default XAMPP configuration often uses an empty password for local development, but configurations differ.

## 4. Open it on your phone over home Wi-Fi
1. Make sure the phone and laptop use the same trusted Wi-Fi network.
2. On Windows, open Command Prompt and run `ipconfig`.
3. Find the laptop's IPv4 Address for the Wi-Fi adapter (for example, `192.168.1.25`).
4. On the phone, visit `http://LAPTOP-IP/HomeManager/`, replacing `LAPTOP-IP` with your actual IPv4 address. Example: `http://192.168.1.25/HomeManager/`.
5. If it does not open, check that Apache is running and Windows Firewall permits Apache on your **Private** network. Do not turn off the firewall entirely. Never expose this development app directly to the public internet.

Your laptop must remain on, and Apache/MySQL must be running while the phone uses the app.

## Features included
- Dashboard with current-month income and expenses, low-stock count and pending chores
- Add/delete income and expense records
- Add inventory items and update their quantities
- Low-stock indicators
- Add shopping items, estimate costs, mark as purchased
- Add chores, assign a person, set due dates and mark done
- Responsive layout for laptop and phone
- Prepared SQL statements, output escaping and CSRF tokens on forms

## Database tables
- `expenses`: income and expenses
- `inventory`: household items and quantities
- `shopping_items`: shopping list and purchase status
- `chores`: family tasks and completion status

## Important safety notes
- This starter version has no login system. Use it only on a trusted private home network and do not forward ports or expose it to the internet.
- Anyone who can access the app on the network can view, add or delete records. Add user authentication and role permissions before using it with untrusted users.
- Back up the `home_manager` database regularly using phpMyAdmin > Export.
- Do not store bank passwords, PINs, or other highly sensitive secrets in this app.
